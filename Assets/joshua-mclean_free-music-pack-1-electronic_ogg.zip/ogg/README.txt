Free Music Pack 1: Electronic
By Joshua McLean

______________________
\ LICENSE INFO
 ---------------------

These tracks are released under a CREATIVE COMMONS ATTRIBUTION 4.0 INTERNATIONAL
license. See LICENSE.txt for the full text of the license.

You MUST include the FOLLOWING CREDIT in YOUR MEDIA (game, video, etc.):

  Contains music ©2020 Joshua McLean (https://joshua-mclean.itch.io)
  Licensed under Creative Commons Attribution 4.0 International

Any unauthorized use (i.e. without the above credit) presents as copyright
infringement and is strictly illegal.

______________________
\ INCLUDED TRACKS
 ---------------------

blue blast / 4-4 chip synth arcade/intense backing
140bpm / loop 0:00

fate of them all / 4-4 digirock boss
151bpm / loop 0:03.17

fight with power / 4-4 chip synth battle/boss
140bpm / loop 0:01.71

laboratory electric / 4-4 synth backing
140bpm / loop 0:01.71

mysterious wave / 4-4 synth backing/cinematic
130bpm / loop 0:00

stasis / 4-4 synth backing upbeat
142bpm / loop 0:00

______________________
\ MORE MUSIC
 ---------------------

For more FREE music, visit
https://joshua-mclean.itch.io/

To contact for commissions (original music)
Email / joshua.mclean@8bitstoinfinty.com
Twitter / @mrjoshuamclean
